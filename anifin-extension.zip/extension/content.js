// Cross-browser compatibility
const browser = (typeof chrome !== 'undefined' ? chrome : browser);

// Add download button to anime pages
function addDownloadButton() {
    console.log('AniFin: Checking page for download button');

    const url = window.location.href;
    
    // Check if we're on an anime/serie page
    const isAnimePage = url.includes('/anime/stream/') || url.includes('/serie/stream/');
    
    if (!isAnimePage) {
        console.log('AniFin: Not on an anime page');
        return;
    }
    
    if (document.getElementById('anifin-download-btn')) return;
    
    const button = document.createElement('button');
    button.id = 'anifin-download-btn';
    button.innerHTML = '🔥 Zu Jellyfin hinzufügen';
    button.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        padding: 12px 24px;
        background: linear-gradient(135deg, #00a4dc 0%, #0080b3 100%);
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 15px;
        font-weight: bold;
        box-shadow: 0 4px 12px rgba(0,164,220,0.4);
        transition: all 0.3s ease;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;
    
    button.addEventListener('mouseenter', () => {
        button.style.transform = 'translateY(-2px)';
        button.style.boxShadow = '0 6px 16px rgba(0,164,220,0.5)';
    });
    
    button.addEventListener('mouseleave', () => {
        button.style.transform = 'translateY(0)';
        button.style.boxShadow = '0 4px 12px rgba(0,164,220,0.4)';
    });
    
    button.addEventListener('click', async () => {
        button.disabled = true;
        button.innerHTML = '⏳ Wird hinzugefügt...';
        
        try {
            const result = await browser.storage.local.get(['serverUrl', 'jellyfinToken', 'isConnected']);
            
            if (!result.isConnected || !result.serverUrl || !result.jellyfinToken) {
                alert('❌ Bitte zuerst die Extension einrichten!\n\nKlicke auf das AniFin Icon und melde dich an.');
                button.disabled = false;
                button.innerHTML = '🔥 Zu Jellyfin hinzufügen';
                return;
            }
            
            // Extract base series URL (remove /staffel-X and /episode-X)
            let seriesUrl = window.location.href;
            
            // Remove everything after /staffel- if present
            if (seriesUrl.includes('/staffel-')) {
                seriesUrl = seriesUrl.split('/staffel-')[0];
            }
            
            console.log('AniFin: Sending series URL:', seriesUrl);
            
            // Always send as complete series
            const urlType = 'series';
            
            const response = await fetch(`${result.serverUrl}/api/anifin/queue/add`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Emby-Token': result.jellyfinToken
                },
                body: JSON.stringify({
                    url: seriesUrl,
                    urlType: urlType
                })
            });
            
            if (response.ok) {
                button.innerHTML = '✅ Erfolgreich hinzugefügt!';
                button.style.background = 'linear-gradient(135deg, #28a745 0%, #20873a 100%)';
                
                // Show notification
                showNotification('Erfolgreich zur Download-Queue hinzugefügt!');
                
                setTimeout(() => {
                    button.innerHTML = '🔥 Zu Jellyfin hinzufügen';
                    button.style.background = 'linear-gradient(135deg, #00a4dc 0%, #0080b3 100%)';
                    button.disabled = false;
                }, 3000);
            } else {
                const errorData = await response.json();
                alert(`❌ Fehler: ${errorData.error || 'Konnte nicht zur Queue hinzugefügt werden'}`);
                button.disabled = false;
                button.innerHTML = '🔥 Zu Jellyfin hinzufügen';
            }
        } catch (error) {
            console.error('Error:', error);
            alert(`❌ Fehler: ${error.message}`);
            button.disabled = false;
            button.innerHTML = '🔥 Zu Jellyfin hinzufügen';
        }
    });
    
    document.body.appendChild(button);
}

function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        z-index: 10000;
        padding: 16px 24px;
        background: white;
        border-left: 4px solid #28a745;
        border-radius: 8px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.2);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        color: #333;
        animation: slideIn 0.3s ease;
        max-width: 300px;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize
if (document.readyState === 'loading') {
    console.log('AniFin: Waiting for DOMContentLoaded');
    document.addEventListener('DOMContentLoaded', addDownloadButton);
} else {
    console.log('AniFin: DOMContentLoaded already fired');
    addDownloadButton();
}

// Handle SPA navigation
let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        console.log('AniFin: URL changed, checking for download button');
        addDownloadButton();
    }
}).observe(document, { subtree: true, childList: true });