// Cross-browser compatibility
const browser = (typeof chrome !== 'undefined' ? chrome : browser);

// Load saved settings
browser.storage.local.get(['serverUrl', 'username', 'isConnected'], (result) => {
    if (result.serverUrl) {
        document.getElementById('serverUrl').value = result.serverUrl;
    }
    if (result.username) {
        document.getElementById('username').value = result.username;
    }
    if (result.isConnected) {
        updateConnectionStatus(true);
        loadUserInfo();
    }
});

// Disconnect button handler
document.getElementById('disconnectBtn')?.addEventListener('click', async () => {
    await browser.storage.local.clear();
    updateConnectionStatus(false);
    document.getElementById('password').value = '';
    showStatus('Verbindung getrennt', 'info');
});

// Connect button handler
document.getElementById('connectBtn').addEventListener('click', async () => {
    const serverUrl = document.getElementById('serverUrl').value.trim();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    
    // Remove trailing slash from server URL
    const cleanServerUrl = serverUrl.replace(/\/$/, '');
    
    if (!cleanServerUrl || !username || !password) {
        showStatus('Bitte fülle alle Felder aus', 'error');
        return;
    }
    
    // Validate URL format
    try {
        new URL(cleanServerUrl);
    } catch (e) {
        showStatus('Ungültige Server-URL. Bitte http:// oder https:// verwenden.', 'error');
        return;
    }
    
    // Disable button during connection
    const btn = document.getElementById('connectBtn');
    btn.disabled = true;
    btn.textContent = 'Verbinde...';
    
    try {
        // Authenticate with Jellyfin
        showStatus('Melde bei Jellyfin an...', 'info');
        const authResponse = await fetch(`${cleanServerUrl}/Users/AuthenticateByName`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Emby-Authorization': 'MediaBrowser Client="AniFin Extension", Device="Browser", DeviceId="anifin-ext-' + generateDeviceId() + '", Version="1.0.0"'
            },
            body: JSON.stringify({
                Username: username,
                Pw: password
            })
        });
        
        if (!authResponse.ok) {
            const errorText = await authResponse.text();
            console.error('Auth error:', errorText);
            throw new Error('Anmeldung fehlgeschlagen. Überprüfe deine Zugangsdaten.');
        }
        
        const authData = await authResponse.json();
        const jellyfinToken = authData.AccessToken;
        const userId = authData.User.Id;
        const userDisplayName = authData.User.Name;
        
        // Save everything
        await browser.storage.local.set({
            serverUrl: cleanServerUrl,
            username: username,
            userId: userId,
            userDisplayName: userDisplayName,
            jellyfinToken: jellyfinToken,
            isConnected: true,
            connectedAt: Date.now()
        });
        
        updateConnectionStatus(true);
        loadUserInfo();
        showStatus('✅ Erfolgreich verbunden!', 'success');
        
        // Clear password field
        document.getElementById('password').value = '';
        
    } catch (error) {
        console.error('Connection error:', error);
        showStatus(`❌ ${error.message}`, 'error');
        updateConnectionStatus(false);
        
        // Clear any partial data
        await browser.storage.local.remove(['jellyfinToken', 'isConnected']);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Verbinden';
    }
});

// Allow Enter key to submit
document.getElementById('password').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        document.getElementById('connectBtn').click();
    }
});

function updateConnectionStatus(connected) {
    const statusDiv = document.getElementById('connectionStatus');
    const loginForm = document.getElementById('loginForm');
    const userInfo = document.getElementById('userInfo');
    
    if (connected) {
        statusDiv.innerHTML = 'Status: <span class="connected">✓ Verbunden</span>';
        if (loginForm) loginForm.style.display = 'none';
        if (userInfo) userInfo.style.display = 'block';
    } else {
        statusDiv.innerHTML = 'Status: <span class="disconnected">✗ Nicht verbunden</span>';
        if (loginForm) loginForm.style.display = 'block';
        if (userInfo) userInfo.style.display = 'none';
    }
}

function loadUserInfo() {
    browser.storage.local.get(['username', 'userDisplayName', 'serverUrl', 'connectedAt'], (result) => {
        const userInfoDiv = document.getElementById('userDetails');
        if (userInfoDiv && result.username) {
            const connectedDate = result.connectedAt ? new Date(result.connectedAt).toLocaleDateString('de-DE') : 'Unbekannt';
            userInfoDiv.innerHTML = `
                <div class="user-detail">
                    <strong>Benutzer:</strong> ${result.userDisplayName || result.username}
                </div>
                <div class="user-detail">
                    <strong>Server:</strong> ${result.serverUrl}
                </div>
                <div class="user-detail">
                    <strong>Verbunden seit:</strong> ${connectedDate}
                </div>
            `;
        }
    });
}

function showStatus(message, type) {
    const statusDiv = document.getElementById('status');
    statusDiv.textContent = message;
    statusDiv.className = `status ${type} show`;
    
    if (type === 'success') {
        setTimeout(() => {
            statusDiv.classList.remove('show');
        }, 3000);
    }
}

function generateDeviceId() {
    // Generate a unique device ID
    const stored = localStorage.getItem('anifin-device-id');
    if (stored) return stored;
    
    const deviceId = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
    
    localStorage.setItem('anifin-device-id', deviceId);
    return deviceId;
}